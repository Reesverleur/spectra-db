# src/spectra_db/query/__init__.py
from __future__ import annotations

from spectra_db.query.api import open_default_api

__all__ = ["open_default_api"]
