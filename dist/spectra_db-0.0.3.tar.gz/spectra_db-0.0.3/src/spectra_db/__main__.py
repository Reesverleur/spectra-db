from __future__ import annotations

from spectra_db.cli import main

if __name__ == "__main__":
    main()
