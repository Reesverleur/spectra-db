def test_import():
    import spectra_db  # noqa: F401
